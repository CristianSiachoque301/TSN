<?php
header("Content-Type: application/json");

// Configuración de la base de datos
$host = "localhost";
$dbname = "eduwebb";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Error de conexión: " . $e->getMessage()]);
    exit;
}

// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET': // Listar cursos
        try {
            $stmt = $pdo->query("SELECT id, name, description FROM courses");
            $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($courses) {
                echo json_encode($courses);
            } else {
                echo json_encode(["message" => "No hay cursos disponibles."]);
            }
        } catch (Exception $e) {
            echo json_encode(["error" => "Error al obtener los cursos: " . $e->getMessage()]);
        }
        break;

    case 'POST': // Crear un nuevo curso
        $input = json_decode(file_get_contents("php://input"), true);
        if (isset($input['name'], $input['description'])) {
            $name = $input['name'];
            $description = $input['description'];

            try {
                $stmt = $pdo->prepare("INSERT INTO courses (name, description) VALUES (:name, :description)");
                $stmt->execute(['name' => $name, 'description' => $description]);
                echo json_encode(["message" => "Curso creado exitosamente."]);
            } catch (Exception $e) {
                echo json_encode(["error" => "Error al crear el curso: " . $e->getMessage()]);
            }
        } else {
            echo json_encode(["error" => "Datos incompletos. Se requiere 'name' y 'description'."]);
        }
        break;

    case 'PUT': // Actualizar un curso
        $input = json_decode(file_get_contents("php://input"), true);
        if (isset($input['id'], $input['name'], $input['description'])) {
            $id = $input['id'];
            $name = $input['name'];
            $description = $input['description'];

            try {
                $stmt = $pdo->prepare("UPDATE courses SET name = :name, description = :description WHERE id = :id");
                $stmt->execute(['id' => $id, 'name' => $name, 'description' => $description]);
                echo json_encode(["message" => "Curso actualizado exitosamente."]);
            } catch (Exception $e) {
                echo json_encode(["error" => "Error al actualizar el curso: " . $e->getMessage()]);
            }
        } else {
            echo json_encode(["error" => "Datos incompletos. Se requiere 'id', 'name' y 'description'."]);
        }
        break;

    case 'DELETE': // Eliminar un curso
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            try {
                $stmt = $pdo->prepare("DELETE FROM courses WHERE id = :id");
                $stmt->execute(['id' => $id]);
                echo json_encode(["message" => "Curso eliminado exitosamente."]);
            } catch (Exception $e) {
                echo json_encode(["error" => "Error al eliminar el curso: " . $e->getMessage()]);
            }
        } else {
            echo json_encode(["error" => "Se requiere el ID del curso para eliminarlo."]);
        }
        break;

    default: // Método no permitido
        http_response_code(405); // Método no permitido
        echo json_encode(["error" => "Método no permitido"]);
        break;
}
