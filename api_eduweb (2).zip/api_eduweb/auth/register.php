<?php
include '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);
$name = $data['name'];
$email = $data['email'];
$password = password_hash($data['password'], PASSWORD_DEFAULT);
$role_id = $data['role_id']; // El rol (admin, student, etc.)

$stmt = $pdo->prepare("INSERT INTO profiles (name, email, password, role_id) VALUES (:name, :email, :password, :role_id)");
$stmt->execute(['name' => $name, 'email' => $email, 'password' => $password, 'role_id' => $role_id]);

echo json_encode(['message' => 'Registro exitoso']);
?>
