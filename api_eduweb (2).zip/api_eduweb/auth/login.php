<?php
session_start();
include '../config/database.php';

header("Access-Control-Allow-Origin: http://localhost:3000"); // Permite solicitudes desde el puerto de React
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0); // Responde a las solicitudes OPTIONS de preflight
}




$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'];
$password = $data['password'];

// Verificar si el usuario existe
$stmt = $pdo->prepare("SELECT * FROM profiles WHERE email = :email");
$stmt->execute(['email' => $email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    // Guardar la información del usuario en la sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role_id'];
    echo json_encode(['message' => 'Inicio de sesión exitoso']);
} else {
    http_response_code(401); // Unauthorized
    echo json_encode(['message' => 'Credenciales incorrectas']);
}
?>
