<?php
// middleware/auth.php

// Evitar múltiples inclusiones
require_once '../config/database.php';

// Iniciar la sesión si no está ya iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Verifica si el usuario está autenticado.
 * Redirige con un error 401 si no lo está.
 */
function authenticate() {
    if (!isset($_SESSION['user_id'])) {
        header('HTTP/1.1 401 Unauthorized');
        echo json_encode(['message' => 'No autorizado.']);
        exit();
    }
}

/**
 * Verifica si el usuario tiene el rol adecuado.
 * Redirige con un error 403 si no tiene el rol necesario.
 * 
 * @param string $role El rol requerido para acceder al recurso.
 */
function authorize($role) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
        header('HTTP/1.1 403 Forbidden');
        echo json_encode(['message' => 'No tiene permiso para acceder a esta sección.']);
        exit();
    }
}

/**
 * Valida un token de autorización (por ejemplo, un JWT).
 * Este es un ejemplo básico y debe ajustarse a tu implementación real.
 * 
 * @param string $token El token a validar.
 * @return bool Verdadero si el token es válido, falso de lo contrario.
 */
function validateToken($token) {
    // Aquí deberías usar una librería como firebase/php-jwt para validar el token JWT
    if ($token === 'valid-token') {
        return true;
    }
    return false;
}

/**
 * Verifica si se ha enviado un token de autorización válido.
 * 
 * Redirige con un error 401 si el token no es válido.
 */
function authenticateWithToken() {
    if (!isset($_SERVER['HTTP_AUTHORIZATION'])) {
        header('HTTP/1.1 401 Unauthorized');
        echo json_encode(['message' => 'No autorizado.']);
        exit();
    }

    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    $token = str_replace('Bearer ', '', $authHeader);

    if (!validateToken($token)) {
        header('HTTP/1.1 401 Unauthorized');
        echo json_encode(['message' => 'Token inválido.']);
        exit();
    }
}
?>
