<?php
$request = $_SERVER['REQUEST_URI'];
$endpoint = basename($request);

// Incluir los endpoints correspondientes
if (file_exists('endpoints/' . $endpoint . '.php')) {
    include 'endpoints/' . $endpoint . '.php';
} else {
    http_response_code(404); // Not Found
    echo json_encode(['message' => 'Endpoint no encontrado']);
}
?>
