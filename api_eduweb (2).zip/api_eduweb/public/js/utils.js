function handleError(error) {
    console.error('Ocurrió un error:', error);
    alert('Ocurrió un error, por favor intente nuevamente.');
}
function navigateTo(page) {
    window.location.href = page;
}
// Navegación
function navigateTo(page) {
    window.location.href = page;
}

// Funciones generales
function openAddCourseForm() {
    document.getElementById('add-modal').style.display = 'flex';
}

function closeAddModal() {
    document.getElementById('add-modal').style.display = 'none';
}

function closeEditModal() {
    document.getElementById('edit-modal').style.display = 'none';
}
