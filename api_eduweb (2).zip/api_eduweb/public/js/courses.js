const apiUrl = 'http://localhost/api_eduweb/endpoints/courses.php';

// Cargar lista de cursos
function loadCourses() {
    fetch(apiUrl, { method: 'GET' })
        .then(response => response.json())
        .then(courses => {
            const content = document.getElementById('content');
            content.innerHTML = '';

            if (courses.length === 0) {
                content.innerHTML = '<p>No hay cursos disponibles</p>';
                return;
            }

            courses.forEach(course => {
                content.innerHTML += `
                    <div class="course-card">
                        <h3>${course.name}</h3>
                        <p>${course.description}</p>
                        <button onclick="openEditModal(${course.id}, '${course.name}', '${course.description}')">Editar</button>
                        <button onclick="deleteCourse(${course.id})">Eliminar</button>
                    </div>
                `;
            });
        });
}

// Abrir modal de edición
function openEditModal(id, name, description) {
    document.getElementById('edit-course-id').value = id;
    document.getElementById('edit-course-name').value = name;
    document.getElementById('edit-course-description').value = description;

    document.getElementById('edit-modal').style.display = 'flex';
}

// Actualizar curso
function updateCourse(event) {
    event.preventDefault();
    const id = document.getElementById('edit-course-id').value;
    const name = document.getElementById('edit-course-name').value;
    const description = document.getElementById('edit-course-description').value;

    fetch(`${apiUrl}?id=${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description })
    })
        .then(() => {
            closeEditModal();
            loadCourses();
        });
}

// Eliminar curso
function deleteCourse(id) {
    if (confirm('¿Eliminar este curso?')) {
        fetch(`${apiUrl}?id=${id}`, { method: 'DELETE' })
            .then(() => loadCourses());
    }
}

// Agregar curso
function addCourse(event) {
    event.preventDefault();
    const name = document.getElementById('add-course-name').value;
    const description = document.getElementById('add-course-description').value;

    fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description })
    })
        .then(() => {
            closeAddModal();
            loadCourses();
        });
}

// Cargar cursos al iniciar
window.onload = loadCourses;
